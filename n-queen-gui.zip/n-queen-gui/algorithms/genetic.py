
import random
from algorithms.algorithm_base import AlgorithmBase


class GeneticSolver(AlgorithmBase):
    def fitness(self, board, goal_state):
        clashes = sum(
            1 for i in range(len(board))
            for j in range(i + 1, len(board))
            if board[i] == board[j] or abs(board[i] - board[j]) == abs(i - j)
        )
        goal_distance = sum(1 for i in range(len(board)) if board[i] != goal_state[i])
        return clashes + goal_distance

    def generate_population(self, n, size):
        return [random.sample(range(n), n) for _ in range(size)]

    def ordered_crossover(self, parent1, parent2):
        size = len(parent1)
        start, end = sorted(random.sample(range(size), 2))
        child = [-1] * size
        child[start:end] = parent1[start:end]

        remaining = [gene for gene in parent2 if gene not in child]
        idx = 0
        for i in range(size):
            if child[i] == -1:
                child[i] = remaining[idx]
                idx += 1
        return child

    def tournament_selection(self, population, goal_state, k=5):
        selected = random.sample(population, k)
        return min(selected, key=lambda x: self.fitness(x, goal_state))

    def adaptive_mutation(self, board, diversity_factor, base_rate=0.05):
        mutation_rate = base_rate + (1 - diversity_factor) * 0.2  # افزایش نرخ جهش در صورت کمبود تنوع
        if random.random() < mutation_rate:
            i, j = random.sample(range(len(board)), 2)
            board[i], board[j] = board[j], board[i]
        return board

    def calculate_diversity(self, population):
        unique = len({tuple(ind) for ind in population})
        return unique / len(population)

    def solve(self, start_state, goal_state):
        n = len(start_state)
        population_size = 300
        generations = 3000
        max_stagnant = 150
        elite_count = 5

        population = self.generate_population(n, population_size)
        best_individual = None
        best_fitness = float('inf')
        stagnant_generations = 0

        for gen in range(generations):
            population.sort(key=lambda x: self.fitness(x, goal_state))
            current_best = population[0]
            current_fitness = self.fitness(current_best, goal_state)

            print(f"\n🔄 Generation {gen}: Best = {current_best}, Fitness = {current_fitness}")

            if current_fitness < best_fitness:
                best_fitness = current_fitness
                best_individual = current_best
                stagnant_generations = 0
            else:
                stagnant_generations += 1

            if current_best == goal_state:
                print(f"\n🎯 Exact solution found in generation {gen}: {current_best}")
                return current_best

            if stagnant_generations >= max_stagnant:
                print("\n⚠️ Stagnation detected! Reinitializing half of the population.")
                population[population_size // 2:] = self.generate_population(n, population_size // 2)
                stagnant_generations = 0

            new_population = population[:elite_count]  # elitism

            diversity = self.calculate_diversity(population)

            while len(new_population) < population_size:
                parent1 = self.tournament_selection(population, goal_state)
                parent2 = self.tournament_selection(population, goal_state)
                child = self.ordered_crossover(parent1, parent2)
                mutated_child = self.adaptive_mutation(child, diversity)

                new_population.append(mutated_child)

            population = new_population

        print("\n❌ No solution found within generation limit.")
        print(f"🔚 Best found: {best_individual} with Fitness = {best_fitness}")
        return None
