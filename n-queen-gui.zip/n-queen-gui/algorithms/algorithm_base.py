# algorithms/algorithm_base.py
from abc import ABC, abstractmethod


class AlgorithmBase(ABC):
    """کلاس پایه برای الگوریتم‌های حل مسئله n-queens"""

    @abstractmethod
    def solve(self, start_state, goal_state):
        """هر الگوریتم باید این متد را پیاده‌سازی کند"""
        pass