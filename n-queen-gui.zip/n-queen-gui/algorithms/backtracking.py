from algorithms.algorithm_base import AlgorithmBase

class BacktrackingSolver(AlgorithmBase):
    """حل‌کننده مسئله n-queens با الگوریتم بازگشتی Backtracking (با چاپ مسیر)"""

    def is_safe(self, board, row, col):
        """بررسی امن بودن موقعیت فعلی برای قرار دادن وزیر"""
        for i in range(row):
            if board[i] == col or \
               abs(board[i] - col) == abs(i - row):
                return False
        return True

    def solve_n_queens(self, board, row, goal_state, steps):
        """حل بازگشتی مسئله با ذخیره مراحل"""
        if row == len(board):
            if board == goal_state:
                steps.append(board[:])
                print(f"🎯 هدف نهایی پیدا شد: {board}")
                return board[:]
            return None

        for col in range(len(board)):
            if self.is_safe(board, row, col):
                board[row] = col
                steps.append(board[:])  # ذخیره مرحله فعلی
                print(f"✅ مرحله {len(steps)}: {board}")
                result = self.solve_n_queens(board, row + 1, goal_state, steps)
                if result:
                    return result
                board[row] = -1  # backtrack
                steps.append(board[:])  # حالت برگشت
                print(f"↩️ برگشت به مرحله قبل: {board}")
        return None

    def solve(self, start_state, goal_state):
        """متد اصلی برای حل مسئله با backtracking"""
        n = len(start_state)
        board = [-1] * n  # شروع از صفحه خالی
        steps = []
        result = self.solve_n_queens(board, 0, goal_state, steps)
        return result
