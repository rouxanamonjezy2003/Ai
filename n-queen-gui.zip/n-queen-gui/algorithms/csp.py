import random
from algorithms.algorithm_base import AlgorithmBase


class CspSolver(AlgorithmBase):
    """CSP Solver using Min-Conflicts Algorithm with Goal-Guided Optimization"""

    def get_conflicts(self, board, col, row):
        """محاسبه تعداد برخوردهای مهره در موقعیت (col, row)"""
        conflicts = sum(
            1 for c in range(len(board))
            if c != col and (board[c] == row or abs(c - col) == abs(board[c] - row))
        )
        return conflicts

    def find_conflicted_vars(self, board):
        """بررسی ستون‌هایی که درگیری دارند"""
        return [col for col in range(len(board)) if self.get_conflicts(board, col, board[col]) > 0]

    def fitness(self, board, goal_state):
        """محاسبه امتیاز ترکیبی: تعداد برخوردها + فاصله از مقدار هدف"""
        clashes = sum(
            1 for i in range(len(board))
            for j in range(i + 1, len(board))
            if board[i] == board[j] or abs(board[i] - board[j]) == abs(i - j)
        )
        goal_distance = sum(1 for i in range(len(board)) if board[i] != goal_state[i])
        return clashes + goal_distance  # امتیاز نهایی

    def solve(self, start_state, goal_state, max_steps=1000, restart_interval=50):
        """حل مسئله با هدایت به سمت مقدار هدف"""
        n = len(start_state)
        board = list(start_state)
        steps = [list(board)]

        # بررسی مقدار اولیه و اعمال تغییر در صورت نیاز
        if not self.find_conflicted_vars(board):
            print("⚠️ مقدار اولیه هیچ برخوردی ندارد، تغییر اولیه اعمال می‌شود!")
            board[random.randint(0, n - 1)] = random.randint(0, n - 1)
            steps.append(list(board))

        for step in range(max_steps):
            conflicted = self.find_conflicted_vars(board)

            if not conflicted:  # حل شد!
                print(f"\n🎯 Solution found in {step} steps: {board}")
                print("\n📝 Path to solution:")
                for i, s in enumerate(steps):
                    print(f"Step {i + 1}: {s}")
                self.best_sequence = steps
                return board

            if step % restart_interval == 0:
                board = random.sample(range(n), n)  # بازآغاز برای فرار از مینیمم محلی
                print("🔄 Restart applied! New initial board:", board)
                steps.append(list(board))

            var = random.choice(conflicted)
            best_rows = sorted(range(n), key=lambda r: self.fitness(board[:var] + [r] + board[var + 1:], goal_state))

            # انتخاب مقدار بهینه با کمی احتمال تصادفی
            new_row = best_rows[0] if random.random() > 0.2 else random.choice(best_rows)

            board[var] = new_row
            steps.append(list(board))

            print(f"🔁 Step {step + 1}: Move queen in col {var} to row {new_row} → {board}")

        print("\n❌ No solution found in the given step limit.")
        self.best_sequence = steps
        return None
