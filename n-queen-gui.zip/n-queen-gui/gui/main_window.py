import tkinter as tk
from PIL import Image, ImageTk
from algorithms.backtracking import BacktrackingSolver
from algorithms.genetic import GeneticSolver
from algorithms.csp import CspSolver

from core.move import Move


class NQueensGUI:
    """Graphical interface for displaying the chessboard and queens"""

    def __init__(self, root):
        self.root = root
        self.root.title("N-Queens Solver")
        self.root.configure(bg="#f0f0f0")

        # Board settings
        self.n = 8  # Default value
        self.cell_size = 50
        self.canvas_size = self.n * self.cell_size

        # Load and resize the queen image
        original_image = Image.open("img_1.png")
        resized_image = original_image.resize((45, 45), Image.Resampling.LANCZOS)
        self.queen_image = ImageTk.PhotoImage(resized_image)

        # Main frame for the entire UI
        self.main_frame = tk.Frame(root, bg="#f0f0f0")
        self.main_frame.pack(pady=20)

        # Title label
        self.title_label = tk.Label(self.main_frame, text="N-Queens Solver", font=("Arial", 16, "bold"), bg="#f0f0f0")
        self.title_label.grid(row=0, column=0, columnspan=3, pady=10)

        # Create a frame for the chessboards
        self.frame_boards = tk.Frame(self.main_frame, bg="#f0f0f0")
        self.frame_boards.grid(row=1, column=0, columnspan=3)

        # Create labels above each chessboard
        self.label_start = tk.Label(self.frame_boards, text="Start State", font=("Arial", 12), bg="#f0f0f0")
        self.label_goal = tk.Label(self.frame_boards, text="Goal State", font=("Arial", 12), bg="#f0f0f0")
        self.label_solution = tk.Label(self.frame_boards, text="Solution Path", font=("Arial", 12), bg="#f0f0f0")

        # Place labels above the canvases
        self.label_start.grid(row=0, column=0, pady=5)
        self.label_goal.grid(row=0, column=1, pady=5)
        self.label_solution.grid(row=0, column=2, pady=5)

        # Create three chessboards side by side
        self.canvas_start = tk.Canvas(self.frame_boards, width=self.canvas_size, height=self.canvas_size)
        self.canvas_goal = tk.Canvas(self.frame_boards, width=self.canvas_size, height=self.canvas_size)
        self.canvas_solution = tk.Canvas(self.frame_boards, width=self.canvas_size, height=self.canvas_size)

        self.canvas_start.grid(row=1, column=0, padx=10)
        self.canvas_goal.grid(row=1, column=1, padx=10)
        self.canvas_solution.grid(row=1, column=2, padx=10)

        self.draw_board(self.canvas_start)
        self.draw_board(self.canvas_goal)
        self.draw_board(self.canvas_solution)

        # Inputs
        tk.Label(self.main_frame, text="Number of queens (n):", bg="#f0f0f0").grid(row=2, column=0, pady=5)
        self.entry_n = tk.Entry(self.main_frame)
        self.entry_n.grid(row=2, column=1, pady=5)

        tk.Label(self.main_frame, text="Initial state (e.g., 0,2,4,0):", bg="#f0f0f0").grid(row=3, column=0, pady=5)
        self.entry_start = tk.Entry(self.main_frame)
        self.entry_start.grid(row=3, column=1, pady=5)

        tk.Label(self.main_frame, text="Goal state (e.g., 1,3,0,2):", bg="#f0f0f0").grid(row=4, column=0, pady=5)
        self.entry_goal = tk.Entry(self.main_frame)
        self.entry_goal.grid(row=4, column=1, pady=5)

        # Algorithm selection
        self.algorithm_var = tk.StringVar(value="Backtracking")
        tk.Radiobutton(self.main_frame, text="Backtracking", variable=self.algorithm_var, value="Backtracking",
                       bg="#f0f0f0").grid(row=5, column=0, pady=5)
        tk.Radiobutton(self.main_frame, text="Genetic Algorithm", variable=self.algorithm_var,
                       value="Genetic Algorithm", bg="#f0f0f0").grid(row=5, column=1, pady=5)
        tk.Radiobutton(self.main_frame, text="CSP", variable=self.algorithm_var, value="CSP", bg="#f0f0f0").grid(row=5,
                                                                                                                 column=2,
                                                                                                                 pady=5)

        # Run button
        tk.Button(self.main_frame, text="Run", command=self.run_solver, relief="raised", bg="#5c85d6", fg="white").grid(
            row=6, column=0, columnspan=3, pady=10)

        # Display result
        self.result_label = tk.Label(self.main_frame, text="", bg="#f0f0f0", font=("Arial", 12, "bold"))
        self.result_label.grid(row=7, column=0, columnspan=3, pady=10)

        # Bottom menu (for styling)
        self.bottom_menu = tk.Frame(root, bg="#5c85d6", height=50)
        self.bottom_menu.pack(fill=tk.X, side=tk.BOTTOM)

        self.bottom_label = tk.Label(self.bottom_menu, text="N-Queens Solver - 2025", fg="white", font=("Arial", 10),
                                     bg="#5c85d6")
        self.bottom_label.pack(pady=10)

    def draw_board(self, canvas):
        """Draw the chessboard"""
        for row in range(self.n):
            for col in range(self.n):
                color = "#d9a066" if (row + col) % 2 == 0 else "#804000"
                x1, y1 = col * self.cell_size, row * self.cell_size
                x2, y2 = x1 + self.cell_size, y1 + self.cell_size
                canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="black")

    def draw_queens(self, canvas, state):
        """Display queens on the board using an image"""
        canvas.delete("queen")  # Remove previous queens
        for row, col in enumerate(state):
            x = col * self.cell_size + self.cell_size // 2  # Place queen in center of cell
            y = row * self.cell_size + self.cell_size // 2
            canvas.create_image(x, y, anchor=tk.CENTER, image=self.queen_image, tags="queen")

    def animate_solution(self, sequence, index=0):
        """Animate the solution steps"""
        if index < len(sequence):
            self.draw_queens(self.canvas_solution, sequence[index])
            self.root.after(1000, self.animate_solution, sequence, index + 1)  # Next move after 1 second

    def run_solver(self):
        """Run the solver and display the result"""
        self.n = int(self.entry_n.get())
        start_state = list(map(int, self.entry_start.get().split(",")))
        goal_state = list(map(int, self.entry_goal.get().split(",")))

        algorithm_name = self.algorithm_var.get()
        if algorithm_name == "Backtracking":
            solver = BacktrackingSolver()
        elif algorithm_name == "Genetic Algorithm":
            solver = GeneticSolver()
        elif algorithm_name == "CSP":
            solver = CspSolver()
        else:
            self.result_label.config(text="❌ Invalid algorithm selected!")
            return

        solution = solver.solve(start_state, goal_state)

        if solution:
            self.result_label.config(text="✅ Solution found!")

            # Display initial and goal states
            self.draw_queens(self.canvas_start, start_state)
            self.draw_queens(self.canvas_goal, goal_state)

            # If best_sequence exists, use it
            if hasattr(solver, 'best_sequence') and solver.best_sequence:
                sequence = solver.best_sequence
            else:
                move_tracker = Move(start_state, solution)
                sequence = move_tracker.calculate_moves()

            self.animate_solution(sequence)
        else:
            self.result_label.config(text="❌ No solution found!")


# Run the program
if __name__ == "__main__":
    root = tk.Tk()
    app = NQueensGUI(root)
    root.mainloop()
