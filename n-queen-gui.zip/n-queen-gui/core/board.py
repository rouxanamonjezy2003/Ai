# core/board.py
class Board:
    """مدل صفحه n-queens"""
    def __init__(self, n):
        self.n = n
        self.state = [-1] * n  # مقدار اولیه

    def set_state(self, state):
        """تنظیم وضعیت صفحه"""
        self.state = state

    def display(self):
        """نمایش صفحه"""
        for row in range(self.n):
            line = ""
            for col in range(self.n):
                if self.state[row] == col:
                    line += "Q "
                else:
                    line += ". "
            print(line)
        print("\n")

# core/move.py
class Move:
    """مدیریت مسیر حرکت وزیرها از start به goal"""
    def __init__(self, start, goal):
        self.start = start
        self.goal = goal

    def get_sequence(self):
        """محاسبه مسیر حرکت"""
        return [self.start, self.goal]  # در اینجا فقط نمایش مسیر اولیه و نهایی