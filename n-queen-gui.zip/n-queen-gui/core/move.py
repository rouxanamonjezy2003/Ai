# core/move.py
class Move:
    """مدیریت مسیر حرکت وزیرها از start به goal"""
    def __init__(self, start, goal):
        self.start = start
        self.goal = goal
        self.sequence = []

    def calculate_moves(self):
        """محاسبه مسیر حرکت از start به goal"""
        current_state = self.start[:]
        while current_state != self.goal:
            for i in range(len(current_state)):
                if current_state[i] != self.goal[i]:
                    current_state[i] = self.goal[i]
                    self.sequence.append(current_state[:])  # ذخیره وضعیت جدید
        return self.sequence

    def display_moves(self):
        """نمایش مسیر حرکت وزیرها"""
        print("مسیر حرکت از Start به Goal:")
        for step, state in enumerate(self.sequence):
            print(f"مرحله {step + 1}: {state}")
